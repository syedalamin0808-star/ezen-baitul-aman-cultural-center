# Ezen Baitul Aman Cultural Center — Website Starter

A responsive, multilingual (Bangla, English, Arabic, Korean) static website starter for Ezen Baitul Aman Cultural Center.

## Included
- Responsive desktop and mobile layout
- Language switcher with Arabic right-to-left layout
- Mosque, Islamic school, Quranic Arabic course, adult Qur'an learning, events, news, contact and gallery sections
- Custom SVG brand mark and favicon
- Google Maps name-search link (replace with the verified exact location)
- No build tools required

## Important before publishing
1. Confirm the full mosque address and replace the location placeholder.
2. Replace the Google Maps search link with the mosque's exact verified Google Maps share link.
3. Add an official email address and any public contact/social links.
4. Replace sample news cards with real announcements and dates.
5. Check all four language translations, particularly official names and event details.
6. Obtain permission before publishing photos of children or community members.
7. Test the site on a phone and computer.

## How to preview
Open `index.html` in a browser. For local testing, you can also run a simple static server from this folder:
`python -m http.server 8000`
Then open `http://localhost:8000`.

## Free publishing with Netlify
1. Create a Netlify account.
2. Unzip the package.
3. Drag the whole `ezen-baitul-aman-cultural-center` folder into Netlify Drop (or follow Netlify's current manual deploy flow).
4. Netlify will provide a temporary public URL.
5. Test the public URL on phone and desktop.

## Content editing limitation
This starter is a static website. The language selector works, but the sample news/events are currently edited in `index.html`; there is no secure admin panel, database, login, registration backend, or payment processing yet. Do not publish sensitive personal information in static files.

## Recommended next upgrade
Connect a CMS with authenticated editing and image uploads (for example, Decap CMS with a suitable Git-based deployment and identity/authentication setup) or choose a managed website platform. Configure access securely before enabling public editing. A CMS setup needs hosting/provider configuration and cannot be enabled merely by adding a front-end login screen.


## Address details supplied by the user
- Address: 92-38 Yuhyeonsaksi-ro, Yangchon-eup, Gimpo-si, Gyeonggi-do, Gimpo, South Korea 10047
- Email: ezenbaitulaman2020@gmail.com
- Phone / WhatsApp: +82 10-5944-9654
- Messenger page name: Ezen Baitul Aman Masjid - ইজেন বাইতুল আমান মসজিদ

The Google Maps button searches using the supplied address; verify the exact pin before launch.


## Phone and WhatsApp
The public site now includes click-to-call and WhatsApp links for +82 10-5944-9654.

## Content admin (one-time setup required)
Open `/admin/` after deployment. The admin scaffold uses Decap CMS and is configured to edit `data/news.json` in four languages. **It will not save edits until the site is connected to a GitHub repository and Netlify Identity + Git Gateway are enabled.** For a static manual drag-and-drop deployment, this cannot be activated from the website alone. Once configured, invite your own email in Netlify Identity and use that login for `/admin/`. Never share your password.

## Redeploy the updated website
1. Extract the latest ZIP.
2. In Netlify, open the existing site and go to Deploys.
3. Upload the extracted project folder (the folder containing `index.html`, `styles.css`, `script.js`, `assets/`, `admin/`, and `data/`).
4. Verify the published URL and test the WhatsApp link.

The included monthly program item is an initial notice for November 21, 2026, at 10 PM after the gathering, based on the current program plan. Confirm it before relying on it as a public announcement.
